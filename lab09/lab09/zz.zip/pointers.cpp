#include "p3.h"
#include <string>
using namespace std;

Election::Election(string office2, string firstCanidiateName2, string secondCanidiateName2) {
    office = office2;
    firstCanidiateName = firstCanidiateName2;
    secondCanidiateName = secondCanidiateName2;
}

string Election::getOffice() const {
    return office;
}
string Election::getCandidate1() const {
    return firstCanidiateName;
}
string Election::getCandidate2() const {
    return secondCanidiateName;
}
string Vote::getOffice() const {
    return vOffice;
}
string Vote::getCandidate() const {
    return canidiateName;
}
bool Vote::wasInPerson() const {
    return voteMadeInPerson;
}
Vote::Vote(string vOffice2, string canidiateName2, bool voteMadeInPerson2) {
    if (vOffice2.empty() == true) {
        vOffice2 = "Unknown";
    }
    vOffice = vOffice2;
    if (canidiateName2.empty() == true) {
        canidiateName2 = "Write In";
    }
    canidiateName = canidiateName2;
    voteMadeInPerson = voteMadeInPerson2;
}
string Ballot::getVoterId() const {
    return voterID;
}
int Ballot::getVoteCount() const {
    return votesStored;
}
const Vote* Ballot::getVote(int votePosition) const {
    Vote* out;
    if (votePosition > -1 && votePosition < votesStored) {
        //unsure if this is proper syntax -- will need testing
        out = votePointer[votePosition];
        return out;
    }
    else {
        out = nullptr;
        return out;
    }
}

void Ballot::recordVote(string office, string candidateName, bool voteInPerson) {
    if ((votesStored + 1) < 6) {
        int x = findVote(office);
        if (x != -1) {
            Vote* z = new Vote(office, candidateName, voteInPerson);
            votePointer[votesStored] = z;
            ++votesStored;
        }
    }
}
int Ballot::countInPersonVotes() {
    int count = 0;
    for (int i = 0; i < votesStored; ++i) {
        bool x = false;
        x = votePointer[i]->wasInPerson();
        if (x == true) {
            count++;
        }
    }
    return count;
}


int Ballot::findVote(string office) const {
    //test to make sure this logically works
    int i = 0;
    bool matchCheck = false;
    for (i = 0; i < 6; ++i) {
        if (votePointer[i]->getOffice() == office) {
            matchCheck = true;
            return i + 1;
        }
    }
    if (matchCheck == false) {
        return -1;
    }
}
Ballot::Ballot(string voterID2) {
    voterID = voterID2;
    votesStored = 0;
    for (int i = 0; i < 6; i++) {
        votePointer[i] = 0;
    }
    
}
Ballot::Ballot() {
    voterID = "Invalid ID";
    votesStored = 0;
}
Ballot::~Ballot() {
    /**this is what the prompt asks for, technically.
    the book details that this can be achieved in a more simple matter --
    using the delete[] operator.
    */
    for (int i = 0; i < 6; ++i) {
        delete votePointer[i];
    }
}

//continue from step 8G]
//start testing functions before continue writing