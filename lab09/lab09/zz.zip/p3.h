#pragma once
#include <string>
using namespace std;

class Election {
private:
    string office;
    string firstCanidiateName;
    string secondCanidiateName;
public:
    Election(string office2, string firstCanidiateName2, string secondCanidiateName2);
    string getOffice() const;
    string getCandidate1() const;
    string getCandidate2() const;
};
class Vote {
private:
    string vOffice;
    string canidiateName;
    bool voteMadeInPerson;
public:
    Vote(string vOffice2, string canidiateName2, bool voteMadeInPerson2);
    string getOffice() const;
    string getCandidate() const;
    bool wasInPerson() const;
};
class Ballot {
private:
    string voterID;
    int votesStored;
    Vote* votePointer[6];
public:
    Ballot();
    Ballot(string voterID2);
    ~Ballot();
    string getVoterId() const;
    int getVoteCount() const;
    const Vote* getVote(int votePosition) const;
    void recordVote(string office, string candidateName, bool voteInPerson);
    int countInPersonVotes();
    int findVote(string office) const;
};